# SMA Energy Meter Add-On (legacy)

> This is the legacy branch based on the SMA-EM library
> https://github.com/kellerza/hassio-sma-em/tree/legacy (11 March)
> **While Pull Requests are welcome, there are no plans for new features**



An add-on to receive SMA Energy Meter measurements and push them to Home Assistant through MQTT. Support auto-discovery for the sensors. 

Uses the [SMA-EM](https://github.com/datenschuft/SMA-EM) library.
